#!/bin/bash

cd ~/workspace/angularv61
npm i
cd ~/workspace/data-binding
npm i
cd ~/workspace/data-binding
npm i
cd ~/workspace/forms
npm i
cd ~/workspace/novidades-v9
npm i
cd ~/workspace/pipes
npm i
cd ~/workspace/primeiro-projeto
npm i
cd ~/workspace/requests-http
npm i
cd ~/workspace/servicos
npm i
cd ~/workspace
