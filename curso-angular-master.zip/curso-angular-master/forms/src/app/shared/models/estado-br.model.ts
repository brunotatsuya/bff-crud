export interface EstadoBr {
  id: number;
  sigla: string;
  nome: string;
}
